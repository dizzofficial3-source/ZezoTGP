const https = require('https');

class ChatGPTAPI {
  constructor() {
    this.baseUrl = 'chatgpt.org';
    this.csrfToken = null;
    this.cookie = null;
  }

  async getCSRFFromCookie() {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: this.baseUrl,
        port: 443,
        path: '/',
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        
        const setCookie = res.headers['set-cookie'];
        if (setCookie) {
          this.cookie = setCookie.map(c => c.split(';')[0]).join('; ');
          
          const xsrfMatch = this.cookie.match(/XSRF-TOKEN=([^;]+)/);
          if (xsrfMatch) {
            this.csrfToken = decodeURIComponent(xsrfMatch[1]);
            resolve();
            return;
          }
        }
        
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const match = data.match(/XSRF-TOKEN[=:]\s*["']?([^"'\s&]+)/i);
          if (match) {
            this.csrfToken = match[1];
            resolve();
          } else {
            reject(new Error('CSRF token not found'));
          }
        });
      });

      req.on('error', reject);
      req.end();
    });
  }

  async chat(message) {
    try {
      await this.getCSRFFromCookie();

      const payload = JSON.stringify({
        model: "openai/gpt-4o-mini",
        messages: [{ role: "user", content: message }]
      });

      return new Promise((resolve, reject) => {
        const options = {
          hostname: this.baseUrl,
          port: 443,
          path: '/api/chat',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': this.csrfToken,
            'Cookie': this.cookie || '',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/event-stream',
            'Referer': 'https://chatgpt.org/',
            'Origin': 'https://chatgpt.org',
            'Content-Length': Buffer.byteLength(payload)
          }
        };

        const req = https.request(options, (res) => {
          let buffer = '';
          let fullResponse = '';

          res.on('data', (chunk) => {
            buffer += chunk.toString();
            const lines = buffer.split('\n');
            buffer = lines.pop();

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const dataStr = line.slice(6);
                if (dataStr === '[DONE]') continue;
                try {
                  const data = JSON.parse(dataStr);
                  if (data.choices?.[0]?.delta?.content) {
                    fullResponse += data.choices[0].delta.content;
                  }
                } catch(e) {}
              }
            }
          });

          res.on('end', () => {
            resolve({
              success: true,
              author: "BINTANG",
              data: {
                question: message,
                answer: fullResponse || "Maaf, tidak ada respons."
              }
            });
          });
        });

        req.on('error', reject);
        req.write(payload);
        req.end();
      });
    } catch (error) {
      return {
        success: false,
        author: "BINTANG",
        error: error.message
      };
    }
  }
}

module.exports = { ChatGPTAPI };