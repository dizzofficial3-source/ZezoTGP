const https = require('https');

class Qwen3Coder {
  constructor() {
    this.apiUrl = 'api.free.ai';
    this.endpoint = '/v1/chat/';
    this.model = 'qwen3-coder';
    this.userId = null;
    this.conversation = [];
  }

  generateUserId() {
    this.userId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    return this.userId;
  }

  async chat(message) {
    if (!this.userId) this.generateUserId();

    this.conversation.push({ role: 'user', content: message });

    const payload = {
      messages: this.conversation,
      model: this.model,
      stream: true,
      lang: 'en'
    };

    const postData = JSON.stringify(payload);

    return new Promise((resolve) => {
      let fullAnswer = '';
      
      const options = {
        hostname: this.apiUrl,
        port: 443,
        path: this.endpoint,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-Id': this.userId,
          'Content-Length': Buffer.byteLength(postData),
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      };

      const req = https.request(options, (res) => {
        let buffer = '';
        
        res.on('data', (chunk) => {
          buffer += chunk.toString();
          const lines = buffer.split('\n');
          buffer = lines.pop();
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const jsonStr = line.slice(6);
              if (jsonStr === '[DONE]') continue;
              
              try {
                const parsed = JSON.parse(jsonStr);
                const content = parsed.choices?.[0]?.delta?.content;
                if (content) {
                  fullAnswer += content;
                }
              } catch(e) {}
            }
          }
        });
        
        res.on('end', () => {
          if (fullAnswer) {
            this.conversation.push({ role: 'assistant', content: fullAnswer });
          }
          
          resolve({
            success: true,
            author: 'BINTANG',
            creator: 'BINTANG',
            data: {
              question: message,
              answer: fullAnswer || 'Maaf, tidak ada respons dari server.',
              model: this.model
            }
          });
        });
      });
      
      req.on('error', (error) => {
        resolve({
          success: false,
          author: 'BINTANG',
          creator: 'BINTANG',
          error: error.message
        });
      });
      
      req.write(postData);
      req.end();
    });
  }

  reset() {
    this.userId = null;
    this.conversation = [];
  }
}

module.exports = { Qwen3Coder };