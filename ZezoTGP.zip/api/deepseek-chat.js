const https = require('https');

const BASE_URL = 'deep-seek.ai';

async function getCsrfToken() {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: BASE_URL,
      path: '/',
      method: 'GET',
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let token = null;
        const metaMatch = data.match(/<meta[^>]*name=["']csrf-token["'][^>]*content=["']([^"']+)["']/i);
        if (metaMatch) token = metaMatch[1];
        const jsMatch = data.match(/X-CSRF-TOKEN["']?\s*[:=]\s*["']([^"']+)["']/i);
        if (jsMatch) token = jsMatch[1];
        
        if (token) {
          resolve(token);
        } else {
          reject(new Error('Failed to get CSRF token'));
        }
      });
    });
    req.on('error', () => reject(new Error('Network error')));
    req.end();
  });
}

class DeepSeekChat {
  async chat(prompt) {
    try {
      const csrfToken = await getCsrfToken();
      
      const payload = JSON.stringify({
        model: "deepseek/deepseek-v4-flash",
        messages: [{ role: "user", content: prompt }]
      });

      const options = {
        hostname: BASE_URL,
        path: '/api/chat',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': csrfToken,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Content-Length': Buffer.byteLength(payload)
        }
      };

      return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => {
            let response = '';
            const lines = data.split('\n');
            for (const line of lines) {
              if (line.startsWith('data: ') && !line.includes('[DONE]')) {
                try {
                  const json = JSON.parse(line.substring(6));
                  const content = json.choices?.[0]?.delta?.content;
                  if (content) response += content;
                } catch(e) {}
              }
            }
            resolve({
              success: true,
              author: "BINTANG",
              data: {
                question: prompt,
                answer: response || "Maaf, tidak ada respons."
              }
            });
          });
        });
        req.on('error', reject);
        req.write(payload);
        req.end();
      });
    } catch (error) {
      return {
        success: false,
        author: "BINTANG",
        error: error.message
      };
    }
  }
}

module.exports = { DeepSeekChat };