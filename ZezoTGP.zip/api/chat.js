const express = require('express');
const cors = require('cors');
const { Qwen3Coder } = require('./qwen3.js');
const { DeepSeekV3 } = require('./deepseek-v3.js');
const { DeepSeekChat } = require('./deepseek-chat.js');
const { ChatGPTAPI } = require('./gpt4o.js');

const app = express();
app.use(cors());
app.use(express.json());

// Inisialisasi instance
const qwen3 = new Qwen3Coder();
const deepseekV3 = new DeepSeekV3();
const deepseekChat = new DeepSeekChat();
const gpt4o = new ChatGPTAPI();

// Endpoint utama
app.post('/api/chat', async (req, res) => {
  const { model, message } = req.body;
  
  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }
  
  let result;
  
  try {
    switch (model) {
      case 'zezo_code':
        result = await qwen3.chat(message);
        break;
      case 'zezo_pakar':
        result = await deepseekV3.chat(message);
        break;
      case 'zezo_think':
        result = await deepseekChat.chat(message);
        break;
      case 'zezo_fast':
      case 'zezo_prompt':
        result = await gpt4o.chat(message);
        break;
      default:
        result = await qwen3.chat(message);
    }
    
    if (result.success) {
      res.json({ 
        success: true, 
        response: result.data?.answer || result.response || 'No response',
        model: model
      });
    } else {
      res.json({ 
        success: false, 
        error: result.error || 'Unknown error',
        model: model
      });
    }
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error.message,
      model: model
    });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Export untuk Vercel
module.exports = app;