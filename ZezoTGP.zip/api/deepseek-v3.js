const https = require('https');
const crypto = require('crypto');

class DeepSeekV3 {
  constructor() {
    this.baseURL = 'deep-seek.ai';
    this.endpoint = '/api/chat';
  }

  generateCsrfToken() {
    return crypto.randomBytes(32).toString('base64').slice(0, 40);
  }

  async chat(prompt) {
    const csrfToken = this.generateCsrfToken();
    
    const payload = {
      model: "deepseek/deepseek-v3.2",
      messages: [{ role: "user", content: prompt }]
    };
    
    const postData = JSON.stringify(payload);
    
    const options = {
      hostname: this.baseURL,
      port: 443,
      path: this.endpoint,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': csrfToken,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    return new Promise((resolve) => {
      let fullResponse = '';
      let modelUsed = '';
      
      const req = https.request(options, (res) => {
        let buffer = '';
        
        res.on('data', (chunk) => {
          buffer += chunk.toString();
          const lines = buffer.split('\n');
          buffer = lines.pop();
          
          for (const line of lines) {
            if (line.startsWith(': OPENROUTER')) continue;
            
            if (line.startsWith('data: ') && line.slice(6) !== '[DONE]') {
              try {
                const data = JSON.parse(line.slice(6));
                if (data.choices?.[0]?.delta?.content) {
                  fullResponse += data.choices[0].delta.content;
                }
                if (data.model) modelUsed = data.model;
              } catch(e) {}
            }
          }
        });
        
        res.on('end', () => {
          resolve({
            success: true,
            author: 'BINTANG',
            creator: 'BINTANG',
            data: {
              question: prompt,
              answer: fullResponse.trim() || 'Maaf, tidak ada respons.',
              model: modelUsed || 'deepseek/deepseek-v3.2-20251201'
            }
          });
        });
      });
      
      req.on('error', (error) => {
        resolve({
          success: false,
          author: 'BINTANG',
          creator: 'BINTANG',
          error: error.message
        });
      });
      
      req.write(postData);
      req.end();
    });
  }
}

module.exports = { DeepSeekV3 };